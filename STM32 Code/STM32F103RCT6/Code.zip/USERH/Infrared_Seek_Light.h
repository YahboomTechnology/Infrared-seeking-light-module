#ifndef __INFRARED_SEEK_LIGHT_H__
#define __INFRARED_SEEK_LIGHT_H__

#include "stm32f10x.h"
#include "UART.h"

void Infrared_Seek_Light_Init(void);//红外避障寻光模块引脚初始化
void Infrared_Seek_Light_State(void);//红外避障寻光模块 检测状态

#endif
