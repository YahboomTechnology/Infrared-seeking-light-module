#include "Infrared_Seek_Light.h"

void Infrared_Seek_Light_Init(void)//红外避障寻光模块引脚初始化
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* GPIOA Periph clock enable */
	/* 使能 DPIOA 时钟 */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	/* Configure PA1 PA2 in GPIO_Mode_IPU mode */
	//红外避障寻光模块对应 LT寻光输出:PA1	HW避障输出:PA2
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/*
说明：
			本例程只提供简单的单个模块测试功能，可以通过该例程调节循迹模块的灵敏度
			如果想实现寻光功能，则需要搭配两个红外避障寻光模块

			若想驱动小车：可结合自己的电机驱动代码文件
			对两个红外避障寻光模块的各个检测状态进行判断，根据判断加入电机驱动控制
*/

void Infrared_Seek_Light_State(void)//红外避障寻光模块 检测状态
{
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == Bit_RESET)
	{
		printf("Seek_Light module detected an obstacle!\n");
	}
	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == Bit_RESET)
	{
		printf("Infrared_Obstacle module detected an obstacle!\n");
	}
}
