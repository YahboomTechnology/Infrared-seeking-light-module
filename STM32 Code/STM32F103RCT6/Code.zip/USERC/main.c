#include "stm32f10x.h"
#include "UART.h"
#include "SysTick.h"
#include "Infrared_Seek_Light.h"

int main(void)
{

    SysTick_Init();//滴答定时器初始化
    UART1_Init();//UART1初始化
		Infrared_Seek_Light_Init();//红外避障寻光模块引脚初始化
		printf("Infrared_Seek_Light!\n");
	
    while(1)
    {
			Infrared_Seek_Light_State();//红外避障寻光模块 检测状态
			Delay_us(1000000);
    }
}
